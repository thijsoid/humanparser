Dear HUMAN,

Welcome to HUMAN PARSER, a pen-and-paper text-adventure about (not) understanding yourself. 

Alongside this file, you should find 4 more:
* Human-Parser-manual-v20250610.pdf  : a shared manual
* Human-Parser-booklet-v20250610.pdf : the same manual in A4 booklet form
* Human-Parser-H-sheet-v20250610.pdf : one role's character sheet
* Human-Parser-P-sheet-v20250610.pdf : another role's character sheet

The manual and two sheets are required to play the game. 

Printing instructions:
* Printing the manual in color is necessary
* The character sheets can be printed duplex long-edge
* The manual might be printed using the delivered booklet: print on A4, duplex long-edge. Cut each sheet in half width-wise and fold and assemble to get an A6 booklet.

~ THIJS
